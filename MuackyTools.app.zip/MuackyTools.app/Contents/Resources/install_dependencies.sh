#!/bin/bash

# This script installs QEMU using a provided Homebrew path.
# The first argument ($1) MUST be the full, absolute path to the brew executable.

BREW_EXECUTABLE="$1"

if [ -z "$BREW_EXECUTABLE" ] || ! [ -x "$BREW_EXECUTABLE" ]; then
    echo "Error: A valid path to the Homebrew executable was not provided."
    exit 1
fi

echo "Using Homebrew at $BREW_EXECUTABLE to install QEMU..."
echo "This may take a few minutes."

# Execute the installation using the full path.
if "$BREW_EXECUTABLE" install qemu; then
    echo "QEMU installed successfully."
else
    echo "QEMU installation failed. Please check the output from Homebrew above."
    exit 1
fi

exit 0
